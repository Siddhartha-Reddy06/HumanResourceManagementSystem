import React from 'react';
import './App.css';
import ProductManagement from './components/ProductManagement';

function App() {
  return (
    <div className="App">
      <ProductManagement />
    </div>
  );
}

export default App;

